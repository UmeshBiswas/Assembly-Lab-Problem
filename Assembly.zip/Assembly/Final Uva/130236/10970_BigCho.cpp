#include<iostream>
using namespace std;
int main ()
{
        int m , n;
        while(cin>>m>>n)
        {
                int res = (m*n) - 1;
                cout<<res<<endl;
        }
        return 0;
}
