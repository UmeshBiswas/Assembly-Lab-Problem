#include<stdio.h>
#include<iostream>
using namespace std;
int main()
{
    char a;
    int j=0;
    while(scanf("%c",&a)==1)
    {
        if(a== '*')
           break;
        else if(a=='H')
            printf("Case %d: Hajj-e-Akbar\n",++j);
        else if(a=='U')
        {
            printf("Case %d: Hajj-e-Asghar\n",++j);
        }

    }
}
